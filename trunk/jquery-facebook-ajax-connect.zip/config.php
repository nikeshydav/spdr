<?php
########## app ID and app SECRET (Replace with yours) #############
$appId = 'xxxxxxxxxxxxxx'; //Facebook App ID
$appSecret = 'xxxxxxxxxxxxxx'; // Facebook App Secret
$return_url = 'http://yourwebsite.com/connect/';  //path to script folder
$fbPermissions = 'publish_stream,email'; // more permissions : https://developers.facebook.com/docs/authentication/permissions/

########## MySql details (Replace with yours) #############
$db_username = "xxxxx"; //Database Username
$db_password = "xxxxx"; //Database Password
$hostname = "xxxxx"; //Mysql Hostname
$db_name = 'demo'; //Database Name
###################################################################

?>