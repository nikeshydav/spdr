@package 	Facebook Ajax Connect
@copyright	Copyright (C) Computer - http://www.saaraan.com All rights reserved.
@license	http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
@author		Saran Chamling (saaraan@gmail.com)
@Websie		http://www.saaraan.com